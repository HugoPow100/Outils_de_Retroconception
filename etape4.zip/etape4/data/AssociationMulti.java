public class AssociationMulti
{
	private Point point;
	private Disque[] disques;

	public AssociationMulti(Point point, Disque[] disques)
	{
		this.point = point;
		this.disques = disques;
	}
}