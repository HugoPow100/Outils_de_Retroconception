public class AssociationTableau
{
	private Point[] points;
	private Disque[] disques;

	public AssociationTableau(Point[] points, Disque[] disques)
	{
		this.points = points;
		this.disques = disques;
	}
}