public interface SimpleInterface
{
	void doSomething();
	int getValue();
}