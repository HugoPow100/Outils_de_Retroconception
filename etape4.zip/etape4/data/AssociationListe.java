import java.util.ArrayList;

public class AssociationListe
{
	private ArrayList<Point> points;
	private ArrayList<Disque> disques;

	public AssociationListe(ArrayList<Point> points, ArrayList<Disque> disques)
	{
		this.points = points;
		this.disques = disques;
	}
}