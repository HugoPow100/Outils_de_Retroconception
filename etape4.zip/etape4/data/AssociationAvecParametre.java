public class AssociationAvecParametre
{
	private Point point;
	private Disque disque;
	private int multiplicite;

	public AssociationAvecParametre(Point point, Disque disque, int multiplicite)
	{
		this.point = point;
		this.disque = disque;
		this.multiplicite = multiplicite;
	}
}