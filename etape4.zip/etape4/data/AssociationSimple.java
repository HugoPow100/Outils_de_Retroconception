public class AssociationSimple
{
	private Point point;
	private Disque disque;

	public AssociationSimple(Point point, Disque disque)
	{
		this.point = point;
		this.disque = disque;
	}
}