public enum Couleur {
	ROUGE,
	VERT,
	BLEU,
	JAUNE
}
