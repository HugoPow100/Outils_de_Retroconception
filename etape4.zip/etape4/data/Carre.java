public class Carre extends Rectangle
{
	public Carre(int cote)
	{
		super(cote, cote);
	}

	public int getCarre(){return 1;}
}